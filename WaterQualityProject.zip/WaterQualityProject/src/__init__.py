"""Water Quality Monitoring & Pollution Detection package."""
